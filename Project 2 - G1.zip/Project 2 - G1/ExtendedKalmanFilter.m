initPlots
clear all
clc

% available files:
csvfilename_motors_off = 'L2Data1.csv';
csvfilename_hover = 'L2Data2.csv';
csvfilename_motion_x = 'L2Data3.csv';
csvfilename_motion_y = 'L2Data4.csv';
csvfilename_motion_z = 'L2Data5.csv';
csvfilename_motion_inf = 'L2Data6.csv';

% read file
csvfilename = csvfilename_motion_x;  % to choose the correct file here
array = dlmread(csvfilename,',',1,0);
T = table2array(readtable(csvfilename, 'VariableNamingRule', 'preserve')); 

% get data from table
time = array(:,1)'*1e-3;
lbd = array(:,8:10)'; % [deg]
gyro = array(:,11:13)';
acc = array(:,14:16)';

% convert date to print format
t = time - time(1);

% simulate system and estimation
Nsim = length(t);

B = zeros(6,0);

g = 9.81;

D = zeros(2,0);

Ts = time(2) - time(1);       % Time Sample

G = [1;0;0;0;0;0];
nx = 6;              

% initial values
P0 = 2*eye(nx);
x0 = zeros(nx,1);


y = [gyro(1:2,:);acc(1:2,:)];
x = zeros(nx,Nsim);
xe = zeros(nx,Nsim);    % x estimado
Pe = zeros(nx,nx,Nsim);

x(:,1) = x0;
xe(:,1) = x0;
Pe(:,:,1) = P0;

for k = 1:Nsim
   
    A  = [ 0 0 1 0 0 0 
                  0 0 0 1 0 0
                  0 0 0 0 0 0
                  0 0 0 0 0 0
                  0 0 0 0 0 0
                  0 0 0 0 0 0];

    F = Ts*A ;

 C  = [ cos(lbd(1,k)*pi/180)*g, 0, 0, 0, 0, 0
           0, -cos(lbd(2,k)*pi/180)*g, 0, 0, 0, 0
           0, 0, 1, 0, 1, 0          
           0, 0, 0, 1, 0, 1 ];
    H = C;
    ny = size(H,1);

    % kalman gains
    Q=eye(6)*10^-4;  % value for Q chosen after several tries to find the most appropriate one
    R= eye(ny);

    % predict next estimate:
    Gu = 0;
    [xem,Pem] = kalman_predict(xe(:,k),Pe(:,:,k),F,Gu,Q);


    % update estimate with measurement info
    [xe(:,k),Pe(:,:,k),K] = kalman_update(xem,Pem,y(:,k),H,R);

   % simulate system dynamics and process noise
    xp = F*x(:,k) + Gu; % process noise not added

    if k < Nsim % update next state until last instant
        x(:,k+1) = xp;
    end
end


l = load ('dados_kalmanfilter_y.mat');

xfl = double(l.dados_kalmanfilter_y);

% Results roll
figure(20041);
plot(t,xe(1,:)*180/pi,t,xfl(1,:)*180/pi,t,lbd(1,:)); 
grid on;
xlabel('$$t$$[s]');
ylabel('$$\phi[deg]$$');
legend('EKF','KF','DataSet3'); % Suitable caption according with the data chosen previously

% Results pitch
figure(20043);
plot(t,xe(2,:)*180/pi,t,xfl(2,:)*180/pi,t,lbd(2,:)); 
grid on;
xlabel('$$t$$[s]');
ylabel('$$\theta[deg]$$');
legend('EKF','KF','DataSet3'); % Suitable caption according with the data chosen previously
