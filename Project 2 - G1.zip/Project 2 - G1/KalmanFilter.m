initPlots
clear all

% available files:
csvfilename_motors_off = 'L2Data1.csv';
csvfilename_hover = 'L2Data2.csv';
csvfilename_motion_x = 'L2Data3.csv';
csvfilename_motion_y = 'L2Data4.csv';
csvfilename_motion_z = 'L2Data5.csv';
csvfilename_motion_inf = 'L2Data6.csv';

% read file
csvfilename = csvfilename_motion_x;  %change file here according to what is meant to be analyzed
array = dlmread(csvfilename,',',1,0);
T = table2array(readtable(csvfilename, 'VariableNamingRule', 'preserve'));

% get data from table
time = array(:,1)'*1e-3;
lbd = array(:,8:10)'; % [deg]
acc = array(:,14:16)';
gyro = array(:,11:13)';


% convert date to print format
t = time - time(1);

A = [ 0 0 0 1 0 0 
      0 0 1 0 0 0
      0 0 0 0 0 0
      0 0 0 0 0 0
      0 0 0 0 0 0
      0 0 0 0 0 0];

B = zeros(6,0);

g=9.81;

C = [ g 0 0 0 0 0
      0 -g 0 0 0 0
      0 0 1 0 1 0          
      0 0 0 1 0 1 ];

D = zeros(4,0);

Ts = time(2) - time(1);  % Time Sample
F = expm(A*Ts);      % discrete state matrix
G = Ts*B; 
H = C;
ny = size(H,1);
nx = size(H,2);   

% kalman gains

Q=eye(6)*10^-4;  % value for Q chosen after several tries to find the most appropriate one
R= eye(ny);

% initial values
P0 = 2*eye(nx);
x0 = zeros(nx,1);

% simulate system and estimation
Nsim = length(t);

y = [gyro(1:2,:);acc(1:2,:)];
xe = zeros(nx,Nsim);   
Pe = zeros(nx,nx,Nsim);
x(:,1) = x0;
xe(:,1) = x0;
Pe(:,:,1) = P0;

for k = 1:Nsim

    % predict next estimate:
    Gu =0;
    [xem,Pem] = kalman_predict(xe(:,k),Pe(:,:,k),F,Gu,Q);
 

    % update estimate with measurement info
    [xe(:,k),Pe(:,:,k),K] = kalman_update(xem,Pem,y(:,k),H,R);

    % simulate system dynamics and process noise
    xp = F*x(:,k) + Gu;  % process noise not added

    if k < Nsim % update next state until last instant
        x(:,k+1) = xp;
    end
end

% Results roll
figure(20041);
plot(t,-xe(1,:)*180/pi,t,lbd(1,:)); 
grid on;
xlabel('$$t$$[s]');
ylabel('$$\phi[deg]$$');
legend('Kalman Filter','DataSet3');  % Suitable caption according with the data chosen previously

% Results pitch
figure(20043);
plot(t,xe(2,:)*180/pi,t,lbd(2,:)); 
grid on;
xlabel('$$t$$[s]');
ylabel('$$\theta[deg]$$');
legend('Kalman Filter','DataSet3');  % Suitable caption according with the data chosen previously
